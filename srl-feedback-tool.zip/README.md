# SRL Feedback Tool

This tool displays a single personalized feedback message combining all SRLs dimensions. 
Students can respond using emoji reactions and add comments.

🟢 Built for GitHub Pages.
🛠️ Future: Store responses using Firebase or Google Sheets API.
